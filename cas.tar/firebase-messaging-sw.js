importScripts("https://www.gstatic.com/firebasejs/9.1.3/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.1.3/firebase-messaging-compat.js");
firebase.initializeApp({
    apiKey: "AIzaSyAaSxnw7-Z95cXsZeFYHO5LQLwC8yEPbp4",
    authDomain: "bqa-fcm.firebaseapp.com",
    projectId: "bqa-fcm",
    storageBucket: "bqa-fcm.appspot.com",
    messagingSenderId: "441415690652",
    appId: "1:441415690652:web:a95d897c0037de7194c059",
    measurementId: "G-5QK3H00QQ4"
});
const messaging = firebase.messaging();